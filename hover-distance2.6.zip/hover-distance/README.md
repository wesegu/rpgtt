# Hover Distance
Show distance to a token on hover without the need to use the ruler
